package de.tuxorials.system.listeners;


import de.tuxorials.system.Main;
import de.tuxorials.system.commands.maxPlayersCommand;
import de.tuxorials.system.utils.Lag;
import org.bukkit.*;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.StriderTemperatureChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.event.server.ServerListPingEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.messaging.PluginMessageListener;
import org.bukkit.scoreboard.*;
import org.bukkit.util.Vector;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.net.InetAddress;

public class otherListener implements Listener {
    FileConfiguration config = Main.plugin.getConfig();
    Scoreboard sb = Main.plugin.sb;
    //FileConfiguration customConfig = YamlConfiguration.loadConfiguration(Main.plugin.customYml);


    @EventHandler
    public void onLeave(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        if (!p.hasPlayedBefore()) {
            e.setQuitMessage("");
        } else {
            e.setQuitMessage(Main.getPrefix() + ChatColor.RED + e.getPlayer().getPlayerListName() + ChatColor.WHITE + " left the Game.");
        }
    }


    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = (Player)e.getPlayer();

        String name = p.getName();


        sb.getTeam("0000000Owner").setPrefix("§4§lOwner | ");
        sb.getTeam("0000010Admin").setPrefix("§c§lAdmin | ");
        sb.getTeam("0000020Dev").setPrefix("§e§lDev | ");
        sb.getTeam("0000030Mod").setPrefix("§6§lMod | ");
        sb.getTeam("0000035Content").setPrefix("§5§lContent | ");
        sb.getTeam("0000040SrSup").setPrefix("§1§lSrSup | ");
        sb.getTeam("0000050Sup").setPrefix("§1§lSup | ");
        sb.getTeam("0000060JrSup").setPrefix("§b§lJrSup | ");
        sb.getTeam("0000070Builder").setPrefix("§2§lBuilder | ");
        sb.getTeam("0000071JrBuilder").setPrefix("§a§oJrBuilder | ");
        sb.getTeam("0000080Strider").setPrefix("§cStrider | ");
        sb.getTeam("0000090Zoglin").setPrefix("§dZoglin | ");
        sb.getTeam("0000100Chicken").setPrefix("§fChicken | ");
        sb.getTeam("0000110Vip").setPrefix("§aV§bI§cP | ");
        sb.getTeam("0000120Og").setPrefix("§bO§cG | ");
        sb.getTeam("0000130Player").setPrefix("§7Player | ");
        if (!p.hasPlayedBefore()) {
            p.kickPlayer(Main.getPrefix() + "\n§4Please join again!");
            e.setJoinMessage("");
        } else {
            p.setPlayerListHeader("§c§lStriderMC");
            p.setPlayerListFooter("§c§lPlayers online (" + Bukkit.getOnlinePlayers().size() + " / " + maxPlayersCommand.maxpl + ")\n§e§lStore " + config.getString("System.shop") + "");

            String team = "";

            if (p.hasPermission("owner")) {
                team = "0000000Owner";
            } else if (p.hasPermission("admin")) {
                team = "0000010Admin";
            } else if (p.hasPermission("dev")) {
                team = "0000020Dev";
            } else if (p.hasPermission("mod")) {
                team = "0000030Mod";
            } else if (p.hasPermission("content")) {
                team = "0000035Content";
            } else if (p.hasPermission("srsup")) {
                team = "0000040SrSup";
            } else if (p.hasPermission("sup")) {
                team = "0000050Sup";
            } else if (p.hasPermission("jrsup")) {
                team = "0000060JrSup";
            } else if (p.hasPermission("builder")) {
                team = "0000070Builder";
            } else if (p.hasPermission("jrbuilder")) {
                team = "0000071JrBuilder";
            } else if (p.hasPermission("strider")) {
                team = "0000080Strider";
            } else if (p.hasPermission("zoglin")) {
                team = "0000090Zoglin";
            } else if (p.hasPermission("chicken")) {
                team = "0000100Chicken";
            } else if (p.hasPermission("vip")) {
                team = "0000110Vip";
            } else if (p.hasPermission("og")) {
                team = "0000120Og";
            } else {
                team = "0000130Player";
            }
            sb.getTeam(team).addPlayer(p);
            p.setPlayerListName(sb.getTeam(team).getPrefix() + p.getName());
            if(!(Bukkit.getOnlinePlayers().size() >= 1)){
            for (Player all : Bukkit.getOnlinePlayers()) {
                all.setScoreboard(sb);
            }}
            p.setPlayerListHeader("§c§lStriderMC");
            p.setPlayerListFooter("§c§lPlayers online (" + Bukkit.getOnlinePlayers().size() + " / " + maxPlayersCommand.maxpl + ")\n§e§lStore " + config.getString("System.shop") + "");

            e.setJoinMessage(Main.getPrefix() + ChatColor.RED + e.getPlayer().getPlayerListName() + ChatColor.WHITE + " joined the Game.");
            if(config.getBoolean("System.lobbyonjoin")) {
                Location location = new Location(Bukkit.getWorld(config.getString("System.lobbyworld")), config.getDouble("System.lobbyposx"), config.getDouble("System.lobbyposy"), config.getDouble("System.lobbyposz"));
                location.setYaw(90);
                p.teleport(location);
            }else{
                Location location = new Location(Bukkit.getWorld(config.getString("System.plotworld")), config.getDouble("System.plotposx"), config.getDouble("System.plotposy"), config.getDouble("System.plotposz"));
                location.setYaw(90);
                p.teleport(location);
            }
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        Player p = (Player) e.getPlayer();
        if (p.getLocation().getBlock().getType() == Material.LIGHT_BLUE_CARPET) {
            if (p.getLocation().subtract(0D, 1D, 0D).getBlock().getType() == Material.BEDROCK) {

                Vector v = p.getLocation().getDirection().multiply(1.5D).setY(1D);
                p.setVelocity(v);

                p.playEffect(p.getLocation(), Effect.ENDER_SIGNAL, 5);
                p.playSound(p.getLocation(), Sound.ENTITY_RABBIT_JUMP, 1F, 1F);

                p.setFallDistance(-999F);
            }
        }
        setPrefix(p);
        Double tps = Lag.getTPS();
        Long tpsec = Math.round(tps);
        p.setPlayerListHeader("§c§lStriderMC");
        p.setPlayerListFooter("§c§lPlayers online (" + Bukkit.getOnlinePlayers().size() + " / " + maxPlayersCommand.maxpl + ")\n§e§lStore " + config.getString("System.shop") + "\n§f§lCurrent TPS: §b" + tpsec.toString());
    }

    @EventHandler
    public void onUse(PlayerInteractEvent e) {
        Player p = (Player) e.getPlayer();
        if (e.getAction().equals(Action.RIGHT_CLICK_AIR)) {
            if (p.hasPermission("System.uptp")) {
                if (e.getItem().equals(new ItemStack(Material.JACK_O_LANTERN))) {
                    Location loc = new Location(p.getWorld(), p.getLocation().getX(), p.getLocation().getY(), p.getLocation().getZ());
                    loc.add(0D, 3D, 0D);
                    loc.setPitch(p.getEyeLocation().getPitch());
                    loc.setYaw(p.getEyeLocation().getYaw());
                    p.teleport(loc);
                }
            }
        }
    }
    //@EventHandler
    public void onRight(PlayerInteractEntityEvent e) {
        Player p = (Player) e.getPlayer();
        Entity pl = e.getPlayer();
        if(p.hasPermission("system.ride")){
            if(!p.isSneaking()) {
                Entity en = e.getRightClicked();
                en.addPassenger((Entity) pl);
            }else{
                Entity en = e.getRightClicked();
                pl.addPassenger(en);
                e.setCancelled(true);
                return;
            }
        }
    }
    @EventHandler
    public void onPong(ServerListPingEvent e){
        e.setMaxPlayers(maxPlayersCommand.maxpl);
    }

    @EventHandler
    public void onPlLogin(PlayerLoginEvent e){
        if(e.getResult().equals(PlayerLoginEvent.Result.KICK_BANNED)){

        }else {
            if (Bukkit.getOnlinePlayers().size() + 1 <= maxPlayersCommand.maxpl) {
                e.allow();
            } else {
                e.disallow(PlayerLoginEvent.Result.KICK_FULL, (String) Bukkit.spigot().getSpigotConfig().get("messages.server-full"));
            }
        }
    }
    //@EventHandler
    public void onLeft(EntityDamageByEntityEvent e) {
        Player p = (Player) e.getDamager();
        Entity pl = e.getDamager();
        if(p.hasPermission("system.ride")){
            if(!pl.getPassengers().contains(e.getEntity())) {
                return;
            }else{
                Entity en = e.getEntity();
                pl.removePassenger((Entity) en);
                e.setCancelled(true);
                return;
            }
        }
    }
    @EventHandler
    public void onPing(ServerListPingEvent e) {
            InetAddress ip = e.getAddress();

            e.setMotd("§c§lStriderMC§f -§9 Your Minecraft Network§r\n§41.16.x§r - §eExperience§a F§cu§bn");


    }

    private void setPrefix(Player p) {
        String team = "";

        if (p.hasPermission("owner")) {
            team = "0000000Owner";
        } else if (p.hasPermission("admin")) {
            team = "0000010Admin";
        } else if (p.hasPermission("dev")) {
            team = "0000020Dev";
        } else if (p.hasPermission("mod")) {
            team = "0000030Mod";
        } else if (p.hasPermission("content")) {
            team = "0000035Content";
        } else if (p.hasPermission("srsup")) {
            team = "0000040SrSup";
        } else if (p.hasPermission("sup")) {
            team = "0000050Sup";
        } else if (p.hasPermission("jrsup")) {
            team = "0000060JrSup";
        } else if (p.hasPermission("builder")) {
            team = "0000070Builder";
        } else if (p.hasPermission("jrbuilder")) {
            team = "0000071JrBuilder";
        } else if (p.hasPermission("strider")) {
            team = "0000080Strider";
        } else if (p.hasPermission("zoglin")) {
            team = "0000090Zoglin";
        } else if (p.hasPermission("chicken")) {
            team = "0000100Chicken";
        } else if (p.hasPermission("vip")) {
            team = "0000110Vip";
        } else if (p.hasPermission("og")) {
            team = "0000120Og";
        } else {
            team = "0000130Player";
        }
        if (!sb.getTeam(team).hasPlayer(p)) {
            sb.getTeam(team).addPlayer(p);
        }
        p.setPlayerListName(sb.getTeam(team).getPrefix() + p.getName());
        p.setScoreboard(sb);
    }

    //@EventHandler
    public void onDmg(EntityDamageEvent e) throws InterruptedException {
        String orig = null;
        if(e.getEntity() instanceof Player){
            Player p = (Player)e.getEntity();
            PlayerInventory pi = p.getInventory();
            ItemStack mh = p.getInventory().getItemInMainHand();
            ItemMeta mhm = mh.getItemMeta();
            if(mhm.hasDisplayName()) {
                orig = mhm.getDisplayName();
            } else {
                orig = null;
            }
            mhm.setDisplayName("§c§lYou just lost "+e.getDamage()+" HP!");
            mh.setItemMeta(mhm);
            p.getInventory().setItemInMainHand(mh);
            Thread.sleep(100);
            if(orig != null) {
                mhm.setDisplayName(orig);
                mh.setItemMeta(mhm);
                p.getInventory().setItemInMainHand(mh);
            }else{
                mhm.setDisplayName(null);
                mh.setItemMeta(mhm);
                p.getInventory().setItemInMainHand(mh);
            }
        }
    }


}

