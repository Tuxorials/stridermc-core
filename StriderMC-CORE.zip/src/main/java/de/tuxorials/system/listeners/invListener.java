package de.tuxorials.system.listeners;

import de.tuxorials.system.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class invListener implements Listener {
    FileConfiguration config = Main.plugin.getConfig();


    @EventHandler
    public void onPlayerClickInventory(InventoryClickEvent e) {
        ItemStack em = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta emeta = em.getItemMeta();
        emeta.setDisplayName("§f");
        em.setItemMeta(emeta);
        ItemStack bm = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta bmeta = em.getItemMeta();
        bmeta.setDisplayName("§f");
        bm.setItemMeta(emeta);

        if(e.getInventory().contains(em)) {
            if(e.getCurrentItem().getItemMeta() != null){
                if(e.getCurrentItem().getItemMeta().getDisplayName() != null){
                    if(e.getCurrentItem().getItemMeta().getDisplayName().equals(ChatColor.GREEN + "Farming area")){
                        Player p = (Player) e.getWhoClicked();
                        Location location = new Location(Bukkit.getWorld(config.getString("System.farmingworld")), config.getDouble("System.farmingposx"), config.getDouble("System.farmingposy"), config.getDouble("System.farmingposz"));
                        location.setYaw(90);
                        p.teleport(location);
                        p.sendMessage(Main.getPrefix() + "You were teleported to the Farming Area!");
                        e.setCancelled(true);
                    }else if(e.getCurrentItem().getItemMeta().getDisplayName().equals(ChatColor.DARK_RED + "Nether area")){
                        Player p = (Player) e.getWhoClicked();
                        Location location = new Location(Bukkit.getWorld(config.getString("System.nether")), config.getDouble("System.netherposx"), config.getDouble("System.netherposy"), config.getDouble("System.netherposz"));
                        location.setYaw(90);
                        p.teleport(location);
                        p.sendMessage(Main.getPrefix() + "You were teleported to the Nether Area!");
                        e.setCancelled(true);
                    }else if(e.getCurrentItem().getItemMeta().getDisplayName().equals(ChatColor.WHITE + "Spawn")){
                        Player p = (Player) e.getWhoClicked();
                        Location location = new Location(Bukkit.getWorld(config.getString("System.plotworld")), config.getDouble("System.plotposx"), config.getDouble("System.plotposy"), config.getDouble("System.plotposz"));
                        location.setYaw(90);
                        p.teleport(location);
                        p.sendMessage(Main.getPrefix() + "You were teleported to the Spawn!");
                        e.setCancelled(true);
                    }else{e.setCancelled(true);}
                }else{}
            }else{}
        }else if(e.getInventory().contains(bm)) {
            if(e.getCurrentItem().getItemMeta() != null){
                if(e.getCurrentItem().getItemMeta().getDisplayName() != null){
                    Player sen = (Player)e.getWhoClicked();
                    CommandSender exec = sen;
                    String title = e.getInventory().getItem(0).getItemMeta().getDisplayName();
                    Player target = Bukkit.getPlayerExact(title);
                    if(e.getCurrentItem().getItemMeta().getDisplayName().equals(ChatColor.DARK_RED + "Combat Hacks")){
                        Player p = (Player) e.getWhoClicked();
                        //target.kickPlayer(Main.getPrefix() + "\nYou were banned!\nReason: §4Combat Hacks");
                        Bukkit.dispatchCommand(exec, "etempban " + title + " 14d §4Combat Hacks");
                        Bukkit.dispatchCommand(exec, "etempbanip " + title + " 2h §4Ban Evading");
                        e.setCancelled(true);
                    }else if(e.getCurrentItem().getItemMeta().getDisplayName().equals(ChatColor.DARK_RED + "Movement Hacks")){
                        Player p = (Player) e.getWhoClicked();
                        //target.kickPlayer(Main.getPrefix() + "\nYou were banned!\nReason: §4Movement Hacks");
                        Bukkit.dispatchCommand(exec, "etempban " + title + " 3d §4Movement Hacks");
                        Bukkit.dispatchCommand(exec, "etempbanip " + title + " 2h §4Ban Evading");
                        e.setCancelled(true);
                    }else if(e.getCurrentItem().getItemMeta().getDisplayName().equals(ChatColor.DARK_RED + "Other - 1 Month")){
                        Player p = (Player) e.getWhoClicked();
                        //target.kickPlayer(Main.getPrefix() + "\nYou were banned!\nReason: §4Other");
                        Bukkit.dispatchCommand(exec, "etempban " + title + " 31d §4Other");
                        Bukkit.dispatchCommand(exec, "etempbanip " + title + " 2h §4Ban Evading");
                        e.setCancelled(true);
                    }else if(e.getCurrentItem().getItemMeta().getDisplayName().equals(ChatColor.WHITE + "Duping")){
                        Player p = (Player) e.getWhoClicked();
                        //target.kickPlayer(Main.getPrefix() + "\nYou were banned!\nReason: §4Duping");
                        Bukkit.dispatchCommand(exec, "etempban " + title + " 1y §4Duping");
                        Bukkit.dispatchCommand(exec, "etempbanip " + title + " 2h §4Ban Evading");
                        e.setCancelled(true);
                    }else if(e.getCurrentItem().getItemMeta().getDisplayName().equals(ChatColor.DARK_RED + "X-Ray")){
                        Player p = (Player) e.getWhoClicked();
                        target.kickPlayer(Main.getPrefix() + "\nYou were banned!\nReason: §4X-Ray");
                        Bukkit.dispatchCommand(exec, "etempban " + title + " 5d §4X-Ray");
                        Bukkit.dispatchCommand(exec, "etempbanip " + title + " 2h §4Ban Evading");
                        e.setCancelled(true);
                    }else if(e.getCurrentItem().getItemMeta().getDisplayName().equals(ChatColor.DARK_RED + "Bug-using")){
                        Player p = (Player) e.getWhoClicked();
                        //target.kickPlayer(Main.getPrefix() + "\nYou were banned!\nReason: §4Bug-Using");
                        Bukkit.dispatchCommand(exec, "etempban " + title + " 14d §4Bug-Using");
                        Bukkit.dispatchCommand(exec, "etempbanip " + title + " 2h §4Ban Evading");
                        e.setCancelled(true);
                    }else if(e.getCurrentItem().getItemMeta().getDisplayName().equals(ChatColor.DARK_RED + "Harming the Server")){
                        Player p = (Player) e.getWhoClicked();
                        //target.kickPlayer(Main.getPrefix() + "\nYou were banned!\nReason: §4Server Harming");
                        Bukkit.dispatchCommand(exec, "etempban " + title + " 14d §4Server Harming");
                        Bukkit.dispatchCommand(exec, "etempbanip " + title + " 2h §4Ban Evading");
                        e.setCancelled(true);
                    }else if(e.getCurrentItem().getItemMeta().getDisplayName().equals(ChatColor.DARK_RED + "Insulting / Inappropriate Word choice")){
                        Player p = (Player) e.getWhoClicked();
                        //target.kickPlayer(Main.getPrefix() + "\nYou were banned!\nReason: §4Insulting / Inappropriate Word choice");
                        Bukkit.dispatchCommand(exec, "etempban " + title + " 2h §4Insulting / Inappropriate Word choice");
                        Bukkit.dispatchCommand(exec, "etempbanip " + title + " 2h §4Ban Evading");
                        e.setCancelled(true);
                    }else if(e.getCurrentItem().getItemMeta().getDisplayName().equals(ChatColor.GREEN + "Un-ban")){
                        Player p = (Player) e.getWhoClicked();
                        Bukkit.dispatchCommand(exec, "eunban " + e.getInventory().getItem(0).getItemMeta().getDisplayName() + "");
                        Bukkit.dispatchCommand(exec, "eunbanip " + e.getInventory().getItem(0).getItemMeta().getDisplayName() + "");
                        Bukkit.getBannedPlayers().remove(target);
                        e.setCancelled(true);
                    }else{e.setCancelled(true);}
                }else{}
            }else{}
        }else{}
    }


}
