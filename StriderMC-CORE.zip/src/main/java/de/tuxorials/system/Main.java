package de.tuxorials.system;

import de.tuxorials.system.commands.*;
import de.tuxorials.system.listeners.invListener;
import de.tuxorials.system.listeners.otherListener;
import de.tuxorials.system.utils.Lag;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Scoreboard;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public final class Main extends JavaPlugin {

    public Map<String, Integer> PlayTime = new HashMap<String, Integer>();

    public static Main plugin;
    public Scoreboard sb;
    public File customYml;
    public FileConfiguration customConfig;
    public void saveCustomYml(FileConfiguration ymlConfig, File ymlFile) {
        try {
            ymlConfig.save(ymlFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onEnable() {
        plugin = this;

        sb = Bukkit.getServer().getScoreboardManager().getNewScoreboard();

        Bukkit.getLogger().fine("Plugin wird aktiviert");
        Bukkit.getLogger().fine("Plugin wird aktualisiert.");
        sb.registerNewTeam("0000000Owner");
        sb.registerNewTeam("0000010Admin");
        sb.registerNewTeam("0000020Dev");
        sb.registerNewTeam("0000030Mod");
        sb.registerNewTeam("0000035Content");
        sb.registerNewTeam("0000040SrSup");
        sb.registerNewTeam("0000050Sup");
        sb.registerNewTeam("0000060JrSup");
        sb.registerNewTeam("0000070Builder");
        sb.registerNewTeam("0000071JrBuilder");
        sb.registerNewTeam("0000080Strider");
        sb.registerNewTeam("0000090Zoglin");
        sb.registerNewTeam("0000100Chicken");
        sb.registerNewTeam("0000110Vip");
        sb.registerNewTeam("0000120Og");
        sb.registerNewTeam("0000130Player");

        listenerRegistration();
        commandRegistration();
        loadConfig();
        repeatingTasks();
        Bukkit.getServer().getScheduler().scheduleSyncRepeatingTask(this, new Lag(), 100L, 1L);

    }




    @Override
    public void onDisable() {
        Bukkit.getLogger().fine("Plugin wird deaktiviert");
    }

    public static String getPrefix() {
        return ChatColor.DARK_GRAY + "[" + ChatColor.RED + "§lStriderMC" + ChatColor.DARK_GRAY + "] " + ChatColor.WHITE;
    }

    private void listenerRegistration() {
        PluginManager pluginManager = Bukkit.getPluginManager();
        pluginManager.registerEvents(new invListener(), this);
        pluginManager.registerEvents(new otherListener(), this);
    }
    Integer whichbc = 1;
    private void repeatingTasks() {
        Bukkit.getScheduler().scheduleSyncRepeatingTask(this, new Runnable() {
            @Override
            public void run() {
                if(whichbc == 1){
                    Bukkit.broadcastMessage(getConfig().getString("System.message1").replace("&", "§"));
                    whichbc++;
                } else if(whichbc == 2){
                    Bukkit.broadcastMessage(getConfig().getString("System.message2").replace("&", "§"));
                    whichbc++;
                } else if(whichbc == 3){
                    Bukkit.broadcastMessage(getConfig().getString("System.message3").replace("&", "§"));
                    whichbc++;
                } else if(whichbc == 4){
                    Bukkit.broadcastMessage(getConfig().getString("System.message4").replace("&", "§"));
                    whichbc++;
                } else{
                    Bukkit.broadcastMessage(getConfig().getString("System.message5").replace("&", "§"));
                    whichbc = 1;
                }

            }
        }, 20, 3600);
        Bukkit.getScheduler().scheduleSyncRepeatingTask(this, new Runnable() {
            @Override
            public void run() {
                for(Player p : Bukkit.getOnlinePlayers()) {
                    PlayTime.put(p.getName(), 1);
                }

            }
        }, 20, 3600);
    }
    private void commandRegistration() {
        getCommand("lobby").setExecutor(new lobbyCommand());
        getCommand("l").setExecutor(new lobbyCommand());
        getCommand("warp").setExecutor(new warpCommand());
        getCommand("warps").setExecutor(new warpCommand());
        getCommand("ban").setExecutor(new banCommand());
        getCommand("nether").setExecutor(new netherCommand());
        getCommand("farm").setExecutor(new farmCommand());
        getCommand("farmworld").setExecutor(new farmCommand());
        getCommand("spawn").setExecutor(new spawnCommand());
        getCommand("tabnick").setExecutor(new nickTabCommand());
        getCommand("executeforall").setExecutor(new executeForAllCommand());
        getCommand("executeforyou").setExecutor(new executeForYouCommand());
        getCommand("maxplayers").setExecutor(new maxPlayersCommand());
    }

    public void loadConfig() {
        getConfig().options().copyDefaults(true);
        saveConfig();
    }
        

}
