package de.tuxorials.system.commands;

import de.tuxorials.system.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

public class lobbyCommand implements CommandExecutor {
    FileConfiguration config = Main.plugin.getConfig();

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (sender instanceof Player) {
            if (sender.hasPermission("system.lobby")) {
                Player p = (Player) sender;

                Location location = new Location(Bukkit.getWorld(config.getString("System.lobbyworld")), config.getDouble("System.lobbyposx"), config.getDouble("System.lobbyposy"), config.getDouble("System.lobbyposz"));
                location.setYaw(90);
                p.teleport(location);
                sender.sendMessage(Main.getPrefix() + "You were teleported to the Lobby!");
            } else {
                Player p = (Player) sender;
                p.sendMessage(Main.getPrefix() + ChatColor.DARK_RED + "You don't have the needed Permission to do this");
            }
        }else{
            sender.sendMessage(Main.getPrefix() + ChatColor.DARK_RED + "You must be an in-game Player to use that!");
        }
        return false;
    }
}
