package de.tuxorials.system.commands;

import de.tuxorials.system.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Scoreboard;

public class nickTabCommand implements CommandExecutor {
    FileConfiguration config = Main.plugin.getConfig();
    Scoreboard sb = Main.plugin.sb;

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (sender instanceof Player) {
            if (sender.hasPermission("system.tabnick")) {

                Player p = ((Player) sender);
                String name = args.toString();
                Integer i;
                p.setDisplayName(args[0].replace("&", "§") + " " + args[1].replace("&", "§") + " " + args[2].replace("&", "§"));
                p.setPlayerListName(args[0].replace("&", "§") + " " + args[1].replace("&", "§") + " " + args[2].replace("&", "§"));
                if(!(Bukkit.getOnlinePlayers().size() >= 1)){
                    for (Player all : Bukkit.getOnlinePlayers()) {
                        all.setScoreboard(sb);
                    }
                }
                p.sendMessage(Main.getPrefix() + "You were nicked as "+name);
            } else {
                Player p = (Player) sender;
                p.sendMessage(Main.getPrefix() + ChatColor.DARK_RED + "You don't have the needed Permission to do this");
            }
        }else{
            sender.sendMessage(Main.getPrefix() + ChatColor.DARK_RED + "You must be an in-game Player to use that!");
        }
        return false;
    }
}
