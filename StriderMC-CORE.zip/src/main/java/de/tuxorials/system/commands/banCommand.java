package de.tuxorials.system.commands;

import de.tuxorials.system.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class banCommand implements CommandExecutor {
    FileConfiguration config = Main.plugin.getConfig();

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        //@TODO: Make Ban reasons and Items modular
        if (args.length == 0) {
        } else {
            Bukkit.getLogger().fine(args[0]);
            if (sender.hasPermission("system.ban")) {

                Inventory inv = Bukkit.createInventory(null, 27, "§c§lBan Menu - " + args[0]);
                ItemStack empty = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
                ItemMeta emptymeta = empty.getItemMeta();
                emptymeta.setDisplayName("§f");
                empty.setItemMeta(emptymeta);
                ItemStack name = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
                ItemMeta namemeta = empty.getItemMeta();
                namemeta.setDisplayName(args[0]);
                name.setItemMeta(namemeta);
                ItemStack farm = new ItemStack(Material.DIAMOND_SWORD);
                ItemMeta farmmeta = farm.getItemMeta();
                farmmeta.setDisplayName(ChatColor.DARK_RED + "Combat Hacks");
                farm.setItemMeta(farmmeta);
                ItemStack nether = new ItemStack(Material.IRON_BOOTS);
                ItemMeta nethermeta = nether.getItemMeta();
                nethermeta.setDisplayName(ChatColor.DARK_RED + "Movement Hacks");
                nether.setItemMeta(nethermeta);
                ItemStack dupe = new ItemStack(Material.SPAWNER);
                ItemMeta dupemeta = dupe.getItemMeta();
                dupemeta.setDisplayName(ChatColor.WHITE + "Duping");
                dupe.setItemMeta(dupemeta);
                ItemStack month = new ItemStack(Material.LAPIS_LAZULI);
                ItemMeta monthmeta = month.getItemMeta();
                monthmeta.setDisplayName(ChatColor.DARK_RED + "Other - 1 Month");
                month.setItemMeta(monthmeta);
                ItemStack cancel = new ItemStack(Material.BARRIER);
                ItemMeta cancelm = cancel.getItemMeta();
                cancelm.setDisplayName(ChatColor.GREEN + "Un-ban");
                ItemStack bug = new ItemStack(Material.STRUCTURE_BLOCK);
                ItemMeta bugmeta = bug.getItemMeta();
                bugmeta.setDisplayName(ChatColor.DARK_RED + "Bug-using");
                bug.setItemMeta(bugmeta);
                ItemStack xray = new ItemStack(Material.DIAMOND);
                ItemMeta xmeta = xray.getItemMeta();
                xmeta.setDisplayName(ChatColor.DARK_RED + "X-Ray");
                xray.setItemMeta(xmeta);
                ItemStack hray = new ItemStack(Material.COMMAND_BLOCK);
                ItemMeta hmeta = hray.getItemMeta();
                hmeta.setDisplayName(ChatColor.DARK_RED + "Harming the Server");
                hray.setItemMeta(hmeta);
                ItemStack iray = new ItemStack(Material.BOOK);
                ItemMeta imeta = iray.getItemMeta();
                imeta.setDisplayName(ChatColor.DARK_RED + "Insulting / Inappropriate Word choice");
                iray.setItemMeta(imeta);
                cancel.setItemMeta(cancelm);
                dupe.setItemMeta(dupemeta);
                inv.setItem(0, name);
                inv.setItem(1, farm);
                inv.setItem(2, nether);
                inv.setItem(3, bug);
                inv.setItem(4, dupe);
                inv.setItem(10, xray);
                inv.setItem(11, hray);
                inv.setItem(12, iray);
                inv.setItem(5, month);
                inv.setItem(7, cancel);
                inv.setItem(26, empty);
                inv.setItem(17, empty);
                inv.setItem(8, empty);
                inv.setItem(9, empty);
                inv.setItem(18, empty);
                Player p = (Player) sender;
                p.openInventory(inv);
            } else{
            Player p = (Player) sender;
            p.sendMessage(Main.getPrefix() + ChatColor.DARK_RED + "You don't have the needed Permission to do this");
            }}
        return false;

    }
}

