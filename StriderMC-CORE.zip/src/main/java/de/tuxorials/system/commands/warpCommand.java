package de.tuxorials.system.commands;

import de.tuxorials.system.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class warpCommand implements CommandExecutor {
    FileConfiguration config = Main.plugin.getConfig();

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (sender instanceof Player) {
            if (sender.hasPermission("system.warp")) {

                Inventory inv = Bukkit.createInventory(null,9,"§a§lWarp Menu");
                ItemStack empty = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
                ItemMeta emptymeta = empty.getItemMeta();
                emptymeta.setDisplayName("§f");
                empty.setItemMeta(emptymeta);
                ItemStack farm = new ItemStack(Material.OAK_LOG);
                ItemMeta farmmeta = farm.getItemMeta();
                farmmeta.setDisplayName(ChatColor.GREEN + "Farming area");
                farm.setItemMeta(farmmeta);
                ItemStack nether = new ItemStack(Material.NETHERRACK);
                ItemMeta nethermeta = nether.getItemMeta();
                nethermeta.setDisplayName(ChatColor.DARK_RED + "Nether area");
                nether.setItemMeta(nethermeta);
                ItemStack plot = new ItemStack(Material.OAK_DOOR);
                ItemMeta plotmeta = plot.getItemMeta();
                plotmeta.setDisplayName(ChatColor.WHITE + "Spawn");
                plot.setItemMeta(plotmeta);
                inv.setItem(0, empty);
                inv.setItem(2, farm);
                inv.setItem(4, nether);
                inv.setItem(6, plot);
                inv.setItem(8, empty);
                Player p = (Player) sender;
                p.openInventory(inv);
            } else {
                Player p = (Player) sender;
                p.sendMessage(Main.getPrefix() + ChatColor.DARK_RED + "You don't have the needed Permission to do this");
            }
        }else{
            sender.sendMessage(Main.getPrefix() + ChatColor.DARK_RED + "You must be an in-game Player to use that!");
        }
        return false;
    }
}
