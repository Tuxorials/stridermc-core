package de.tuxorials.system.commands;

import de.tuxorials.system.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

public class maxPlayersCommand implements CommandExecutor {
    FileConfiguration config = Main.plugin.getConfig();
    public static Integer maxpl = (Integer) Bukkit.spigot().getConfig().get("max-players");

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 1) {
            if (sender.hasPermission("system.maxpl")) {
                maxpl = Integer.valueOf(args[0]);
                sender.sendMessage(Main.getPrefix() + "The Maximum Player count was set to " + args[0] + "!");
                Bukkit.spigot().getConfig().set("max-players", maxpl);


            } else {
                Player p = (Player) sender;
                p.sendMessage(Main.getPrefix() + ChatColor.DARK_RED + "You don't have the needed Permission to do this");
            }
        } else {
            sender.sendMessage(Main.getPrefix() + ChatColor.DARK_RED + "You must provide a Player count to use that!");
        }
        return false;
    }

}
