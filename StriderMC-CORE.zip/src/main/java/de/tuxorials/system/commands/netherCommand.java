package de.tuxorials.system.commands;

import de.tuxorials.system.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class netherCommand implements CommandExecutor {
    FileConfiguration config = Main.plugin.getConfig();

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (sender instanceof Player) {
            if (sender.hasPermission("system.warp")) {
                Player p = (Player) sender;
                Location location = new Location(Bukkit.getWorld(config.getString("System.nether")), config.getDouble("System.netherposx"), config.getDouble("System.netherposy"), config.getDouble("System.netherposz"));
                location.setYaw(90);
                p.teleport(location);
                p.sendMessage(Main.getPrefix() + "You were teleported to the Nether Area!");
            } else {
                Player p = (Player) sender;
                p.sendMessage(Main.getPrefix() + ChatColor.DARK_RED + "You don't have the needed Permission to do this");
            }
        }else{
            sender.sendMessage(Main.getPrefix() + ChatColor.DARK_RED + "You must be an in-game Player to use that!");
        }
        return false;
    }
}
