package de.tuxorials.system.commands;

import de.tuxorials.system.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

public class executeForAllCommand implements CommandExecutor {
    FileConfiguration config = Main.plugin.getConfig();
    Integer i;

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
            if (sender.hasPermission("system.efa")) {

                String comm = "";
                String commtoex = "";
                for(i = 0; i<args.length; i++){
                    comm = comm + args[i]+ " ";
                }
                System.out.println(comm);

                for(Player all : Bukkit.getOnlinePlayers()){
                    for(Player name : Bukkit.getOnlinePlayers()){
                        commtoex = comm.replace("@a", name.getName());
                        commtoex = commtoex.replace("@s", all.getName());
                        all.chat(commtoex);
                    }
                }

                sender.sendMessage(Main.getPrefix() + "You successfully executed that command for all Players!");
            } else {
                Player p = (Player) sender;
                p.sendMessage(Main.getPrefix() + ChatColor.DARK_RED + "You don't have the needed Permission to do this");
            }
        return false;
    }
}
